export default function Dashboard() {
  return (
    <div style={{ padding: 40, fontFamily: 'Arial' }}>
      <h1>Dashboard</h1>
      <p>Create your AI content here</p>
    </div>
  );
}
