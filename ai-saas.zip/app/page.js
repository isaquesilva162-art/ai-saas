export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'Arial' }}>
      <h1>AI SaaS Generator</h1>
      <p>Generate posts, ads and content with AI</p>
      <a href='/dashboard'>Go to Dashboard</a>
    </div>
  );
}
