import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || ""
});

export async function POST(req) {
  const { prompt } = await req.json();

  try {
    const response = await client.responses.create({
      model: "gpt-4.1-mini",
      input: prompt
    });

    return Response.json({ result: response.output_text });
  } catch (e) {
    return Response.json({ error: "AI error" });
  }
}
